package clarificationsServerSide;

public class clarificationClassTestServerSide {
    public static void main(String[] args) {
        DBConClarificationsServer.addClarification("what is your name", "amr");
        DBConClarificationsServer.addClarification("what is your age", "3312");
        DBConClarificationsServer.addClarification("what is your mission", "null");
        DBConClarificationsServer.addClarification("what is your fav thing", "MLW");
    }
}
